#!/bin/sh

release_ctl eval --mfa "ZaZaar.ReleaseTasks.seed/1" -- "$@"
