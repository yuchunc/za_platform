#!/bin/sh

release_ctl eval --mfa "ZaZaar.ReleaseTasks.migrate/1" -- "$@"
