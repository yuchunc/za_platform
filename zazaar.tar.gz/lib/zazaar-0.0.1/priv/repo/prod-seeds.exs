require Logger

Logger.info("Start prod seeds")
Logger.info("End prod seeds")
