require Logger

Logger.info("Start test seeds")
Logger.info("End test seeds")
